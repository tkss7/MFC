//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OdbcDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_ODBCDEMO_FORM               101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_OdbcDemoTYPE                130
#define IDS_EDIT_MENU                   306
#define IDC_List                        1000
#define IDC_Edit_Name                   1001
#define IDC_Edit_PhoneNumber            1002
#define IDC_Edit_Address                1003
#define IDC_Edit_Age                    1004
#define IDC_Button_AddNew               1005
#define IDC_Button_UpdateCurrent        1006
#define IDC_Button_DeleteCurrent        1007
#define IDC_Button_DeleteCurrent2       1008
#define IDC_Button_FindRecord           1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        310
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
