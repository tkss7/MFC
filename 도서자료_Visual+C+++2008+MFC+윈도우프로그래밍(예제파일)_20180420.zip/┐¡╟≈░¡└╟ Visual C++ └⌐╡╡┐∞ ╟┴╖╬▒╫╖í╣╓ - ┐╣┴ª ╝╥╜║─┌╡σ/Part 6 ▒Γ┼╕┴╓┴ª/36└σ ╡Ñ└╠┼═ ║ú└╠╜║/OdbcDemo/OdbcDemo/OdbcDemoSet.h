
// OdbcDemoSet.h: COdbcDemoSet Ŭ������ �������̽�
//


#pragma once

// code generated on 2008�� 11�� 7�� �ݿ���, ���� 7:19

class COdbcDemoSet : public CRecordset
{
public:
	COdbcDemoSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(COdbcDemoSet)

// Field/Param Data

// The string types below (if present) reflect the actual data type of the
// database field - CStringA for ANSI datatypes and CStringW for Unicode
// datatypes. This is to prevent the ODBC driver from performing potentially
// unnecessary conversions.  If you wish, you may change these members to
// CString types and the ODBC driver will perform all necessary conversions.
// (Note: You must use an ODBC driver version that is version 3.5 or greater
// to support both Unicode and these conversions).

	long	m_SeqNum;
	CStringW	m_Name;
	CStringW	m_PhoneNumber;
	CStringW	m_Address;
	long	m_Age;

// Overrides
	// Wizard generated virtual function overrides
	public:
	virtual CString GetDefaultConnect();	// Default connection string

	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);	// RFX support

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

