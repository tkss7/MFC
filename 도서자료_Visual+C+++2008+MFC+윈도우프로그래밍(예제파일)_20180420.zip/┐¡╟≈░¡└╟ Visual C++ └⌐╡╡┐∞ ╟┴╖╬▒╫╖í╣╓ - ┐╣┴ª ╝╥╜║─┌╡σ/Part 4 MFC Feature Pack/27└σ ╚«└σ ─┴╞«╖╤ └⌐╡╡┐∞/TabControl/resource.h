//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TabControl.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDD_TABCONTROL_FORM             101
#define IDR_MAINFRAME                   128
#define IDR_TABCONTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDR_POPUP_STYLE_20007           132
#define IDB_TOOLBAR256                  151
#define IDR_THEME                       154
#define IDB_ICONS                       155
#define IDD_ABOUTBOX                    999
#define IDC_COMPANY_URL                 1041
#define IDC_TAB                         1042
#define IDC_TAB_STYLE                   1043
#define IDC_LOCATION                    1044
#define IDC_LOCATION2                   1045
#define IDC_COLOR                       1046
#define IDC_COLOR1                      1047
#define IDC_COLOR2                      1048
#define IDC_TAB_ICONS                   1049
#define IDC_NOTIFICATIONS               1050
#define IDC_TAB_SWAP                    1051
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_APPLOOK_2000            32832
#define ID_VIEW_APPLOOK_XP              32833
#define ID_VIEW_APPLOOK_2003            32834
#define ID_VIEW_APPLOOK_WIN_XP          32835
#define ID_VIEW_APPLOOK_VS2005          32836
#define ID_VIEW_APPLOOK_2007_1          32837
#define ID_VIEW_APPLOOK_2007_2          32838
#define ID_VIEW_APPLOOK_2007_3          32839
#define ID_VIEW_APPLOOK_2007_4          32840
#define ID_VIEW_THEME_TOOLBAR           32841
#define ID_LABEL                        32842

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         32843
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
