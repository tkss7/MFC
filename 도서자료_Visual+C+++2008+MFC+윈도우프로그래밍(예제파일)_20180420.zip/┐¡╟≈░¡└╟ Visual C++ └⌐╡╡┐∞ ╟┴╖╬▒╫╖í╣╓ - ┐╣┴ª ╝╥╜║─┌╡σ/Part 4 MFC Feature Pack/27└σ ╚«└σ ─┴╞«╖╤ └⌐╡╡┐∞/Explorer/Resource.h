//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Explorer.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define ID_VIEW_ARRANGE                 127
#define IDR_MAINFRAME                   128
#define IDR_EXPTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_TOOLBAR256                  151
#define IDB_TOOLBARCOLD256              152
#define IDR_HISTORY_POPUP               154
#define IDR_VIEWS_POPUP                 155
#define IDB_MENU256                     155
#define IDB_MENU16                      156
#define IDD_ABOUTBOX                    999
#define IDC_COMPANY_URL                 1041
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_TOOLS_ENTRY                  32805
#define ID_USER_TOOL1                   32806
#define ID_USER_TOOL2                   32807
#define ID_USER_TOOL3                   32808
#define ID_USER_TOOL4                   32809
#define ID_USER_TOOL5                   32810
#define ID_USER_TOOL6                   32811
#define ID_USER_TOOL7                   32812
#define ID_USER_TOOL8                   32813
#define ID_USER_TOOL9                   32814
#define ID_USER_TOOL10                  32815
#define ID_VIEW_FOLDERS                 32822
#define ID_FOLDER_UP                    32823
#define ID_GO_BACK                      32824
#define ID_GO_FORWARD                   32825
#define ID_MOVE_TO                      32826
#define ID_COPY_TO                      32827
#define ID_VIEW_VIEWS                   32828
#define ID_COMMAND_HISTORY              32829
#define ID_VIEW_REFRESH                 32830

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         32831
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
