#pragma once


// CTestPane

class CTestPane : public CDockablePane
{
	DECLARE_DYNAMIC(CTestPane)

public:
	CTestPane();
	virtual ~CTestPane();

protected:
	DECLARE_MESSAGE_MAP()
};


