// TestPane.cpp : implementation file
//

#include "stdafx.h"
#include "PaneDemo.h"
#include "TestPane.h"


// CTestPane

IMPLEMENT_DYNAMIC(CTestPane, CDockablePane)

CTestPane::CTestPane()
{

}

CTestPane::~CTestPane()
{
}


BEGIN_MESSAGE_MAP(CTestPane, CDockablePane)
END_MESSAGE_MAP()



// CTestPane message handlers


