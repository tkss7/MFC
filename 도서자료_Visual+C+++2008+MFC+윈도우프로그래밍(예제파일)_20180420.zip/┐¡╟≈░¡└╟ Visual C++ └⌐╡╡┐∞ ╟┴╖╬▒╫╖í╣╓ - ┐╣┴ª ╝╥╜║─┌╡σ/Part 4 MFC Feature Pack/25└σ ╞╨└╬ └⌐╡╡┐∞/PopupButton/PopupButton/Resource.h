//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PopupButton.rc
//
#define IDD_ABOUTBOX				100
#define IDP_OLE_INIT_FAILED			100
#define IDR_POPUP_EDIT				119
#define ID_STATUSBAR_PANE1			120
#define ID_STATUSBAR_PANE2			121
#define IDS_STATUS_PANE1			122
#define IDS_STATUS_PANE2			123
#define IDS_TOOLBAR_STANDARD		124
#define IDS_TOOLBAR_CUSTOMIZE		125
#define ID_VIEW_CUSTOMIZE			126
#define IDR_MAINFRAME				128
#define IDR_MAINFRAME_256			129
#define IDR_PopupButtonTYPE				130
#define IDS_EDIT_MENU				306

// ������ �� ��ü�� ����� �⺻���Դϴ�.
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE	310
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		310
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
