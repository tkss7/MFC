//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by VistaButtonDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_VISTABUTTONDEMO_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDC_Split_Button                1000
#define IDC_COMMAND1                    1001
#define IDC_Command_Button              1001
#define ID_SLITBUTTONMENU_TESTMENU1     32771
#define ID_SLITBUTTONMENU_TESTMENU2     32772
#define ID_SLITBUTTONMENU_TESTMENU3     32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
