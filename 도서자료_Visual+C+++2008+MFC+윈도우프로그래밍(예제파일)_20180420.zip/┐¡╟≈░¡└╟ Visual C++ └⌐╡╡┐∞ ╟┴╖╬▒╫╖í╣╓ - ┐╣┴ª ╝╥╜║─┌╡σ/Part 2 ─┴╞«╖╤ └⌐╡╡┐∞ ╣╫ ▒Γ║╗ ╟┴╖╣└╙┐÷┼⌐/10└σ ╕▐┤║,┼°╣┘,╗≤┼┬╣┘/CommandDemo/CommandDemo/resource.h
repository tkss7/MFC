//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CommandDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_CommandDemoTYPE             130
#define IDC_SPLIT1                      1001
#define ID_32772                        32772
#define ID_Menu_Start                   32773
#define ID_32774                        32774
#define ID_Menu_Stop                    32775
#define ID_32778                        32778
#define ID_Menu_Pause                   32779
#define ID_32783                        32783
#define ID_32784                        32784
#define ID_32785                        32785
#define ID_32786                        32786
#define ID_Menu_Sub1                    32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        311
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
